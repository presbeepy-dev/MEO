-- MEO : à exécuter (en entier) dans Supabase → SQL Editor → Run. Peut être relancé sans risque.

-- 1) Projets (privés : chacun ne voit que les siens)
create table if not exists public.projects (
  id uuid primary key,
  owner uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name text not null,
  data jsonb not null default '{"books":[]}',
  updated_at timestamptz not null default now()
);
alter table public.projects enable row level security;
drop policy if exists "owner_all" on public.projects;
create policy "owner_all" on public.projects for all
  using (owner = auth.uid()) with check (owner = auth.uid());

-- 2) Liens de partage (lecture seule), publics ou privés
create table if not exists public.shares (
  token text primary key,
  project_id uuid not null references public.projects(id) on delete cascade,
  book_id text not null,
  access text not null check (access in ('public','private')),
  emails text[] not null default '{}',
  expires_at timestamptz,
  revoked boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.shares enable row level security;
drop policy if exists "owner_shares" on public.shares;
create policy "owner_shares" on public.shares for all
  using (exists (select 1 from public.projects p where p.id = project_id and p.owner = auth.uid()))
  with check (exists (select 1 from public.projects p where p.id = project_id and p.owner = auth.uid()));

-- 3) Lecture d’un livre partagé : seule porte d’accès pour les lecteurs
create or replace function public.get_shared(t text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s public.shares; p public.projects; b jsonb;
begin
  select * into s from public.shares
   where token = t and not revoked and (expires_at is null or expires_at > now());
  if not found then return null; end if;
  if s.access = 'private' then
    if auth.uid() is null
       or not (lower(coalesce(auth.jwt()->>'email','')) = any (array(select lower(x) from unnest(s.emails) x)))
    then return jsonb_build_object('denied', true); end if;
  end if;
  select * into p from public.projects where id = s.project_id;
  select value into b from jsonb_array_elements(p.data->'books') where value->>'id' = s.book_id limit 1;
  if b is null then return null; end if;
  return jsonb_build_object('book', b, 'author', coalesce(p.data->>'author',''));
end $$;
revoke all on function public.get_shared(text) from public;
grant execute on function public.get_shared(text) to anon, authenticated;

-- 4) Droits d’accès à l’API (nécessaires sur les projets Supabase récents ; la sécurité reste assurée par les règles RLS ci-dessus)
grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on public.projects to authenticated;
grant select, insert, update, delete on public.shares to authenticated;

-- 5) Publication publique (site référencé). Seuls les « publishers » peuvent publier ; tout le monde peut LIRE ce qui est publié.
create table if not exists public.publishers (user_id uuid primary key references auth.users(id) on delete cascade);
alter table public.publishers enable row level security;
drop policy if exists "self_publisher" on public.publishers;
create policy "self_publisher" on public.publishers for select using (user_id = auth.uid());

create table if not exists public.published_books (
  id text primary key,
  owner uuid not null default auth.uid() references auth.users(id) on delete cascade,
  project_id uuid,
  slug text not null unique,
  title text not null,
  author_name text not null,
  author_slug text not null,
  real_name text,
  bio text,
  summary text,
  cover_b64 text,
  data jsonb not null,
  published boolean not null default true,
  published_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.published_books enable row level security;
drop policy if exists "public_read" on public.published_books;
create policy "public_read" on public.published_books for select using (published);
drop policy if exists "publisher_write" on public.published_books;
create policy "publisher_write" on public.published_books for all
  using (owner = auth.uid())
  with check (owner = auth.uid() and exists (select 1 from public.publishers x where x.user_id = auth.uid()));
grant select on public.published_books to anon;
grant select, insert, update, delete on public.published_books to authenticated;
grant select on public.publishers to authenticated;

-- 6) VOUS autoriser à publier (à exécuter une fois) :
insert into public.publishers (user_id)
  select id from auth.users where email = 'berlvispresley16@gmail.com'
  on conflict do nothing;
